# pragma once
# include "../message.h"
# include <iostream>
# include <map>
# include <vector>
#include <sys/select.h>



typedef struct AcsItem {
  int conn;
  int pri_ip;
}AcsItem;

class AcsItem_finder {
  private:
    int _conn;
    int _pri_ip;

  public:
    AcsItem_finder(int conn, int pri_ip) : _conn(conn), _pri_ip(pri_ip){}
    bool operator ()(std::vector<AcsItem>::value_type &value) {
      if ( _conn == value.conn ) {
        return true;
      } 

      if ( _pri_ip == value.pri_ip ) {
        return true;
      }
      return false;
    }
};


typedef struct HoleInfo {
  int source_fd;
  int dest_pri_ip;
  MacInfo source;
  MacInfo dest;
}HoleInfo;

class Server {
  typedef struct Connection {
    int conn;
    bool used;
  }Connection;

  typedef enum cAction {
    add_conn,
    del_conn,
  }cAction;

  private:
    int _lfd;
    int _cfd;
    int _connCnt;
    static const int max_conns = 1022;
    Connection _conns[max_conns];
    std::vector<AcsItem> _acsLst;
    std::map<HoleKey, HoleInfo> _holeTbl;

  public:
    Server();
    ~Server();

    void EventLoop(int lPort, int hPort);

  private:
    int _listenTo(int port, int& fd);
    int _accept(int fd, fd_set& eSet, int& maxFd);
    int _handle(int fd, fd_set& all_set);
    int _recv(int fd, Message** m);
    int _send(int fd, const Message* m);
    int _getPeerSock(int fd, int& pub_ip, int& pub_port);

    void _connOpt(cAction a, int fd);
};
