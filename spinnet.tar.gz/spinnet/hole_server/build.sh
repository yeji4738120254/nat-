#!/bin/sh
rm ../message.h.gch hole_server.h.gch
g++ -o hole_server -g ../message.h ../message.cpp  ../tool.h ../tool.cpp hole_server.h hole_server.cpp
