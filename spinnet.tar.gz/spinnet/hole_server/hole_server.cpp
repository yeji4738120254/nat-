# include "hole_server.h"
#include "../tool.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <unistd.h>
#include <string.h>
#include <arpa/inet.h>
#include <algorithm>

using namespace std;

Server::Server():_lfd(0), _cfd(0), _connCnt(0){
}

Server::~Server() {
  for (int i = 0; i < max_conns; i++) {
    if (_conns[i].conn != 0) {
      close(_conns[i].conn);
      _conns[i].used = false;
    }
  }
  _connCnt = 0;
}

int Server::_listenTo(int port, int& fd) {
  int lfd = socket(AF_INET, SOCK_STREAM, 0);
  fd = lfd;
  if (lfd < 0) {
    return -1;
  }

  int on = 1;
  if ( setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(int)) == -1) {
    return -2;
  }

  struct sockaddr_in svr_addr;
  memset(&svr_addr, 0, sizeof(struct sockaddr_in));
  svr_addr.sin_family = AF_INET;
  svr_addr.sin_port = htons(port);
  svr_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  if ( bind(lfd, (struct sockaddr*)&svr_addr, sizeof(sockaddr_in)) == -1 ){
    return -3;
  }

  if ( listen(lfd, 5) == -1) {
    return -4;
  }
  return lfd;
}


void Server::EventLoop(int lPort, int hPort) {
  int lfd = 0, hfd = 0;
  if (_listenTo(lPort, lfd) < 0 || _listenTo(hPort, hfd) < 0 ){
    if (lfd > 0) {
      close(lfd);
    }

    if (hfd > 0) {
      close(hfd);
    }

    cout << "server initialize error" << endl;
    return;
  }

  fd_set all_set, r_set;
  FD_ZERO(&all_set);
  FD_SET(lfd, &all_set);
  FD_SET(hfd, &all_set);
  int maxFd = (lfd > hfd ? lfd : hfd);

  while(1) {
    FD_ZERO(&r_set);
    r_set = all_set;

    if (select(maxFd + 1, &r_set, NULL, NULL, NULL) < 0) {
      cout << "detach even error..." << endl;
      continue;
    }

    if (FD_ISSET(lfd, &r_set)) {
      _accept(lfd, all_set, maxFd);
    }

    if (FD_ISSET(hfd, &r_set)) {
      _accept(hfd, all_set, maxFd);
    }

    int size = _connCnt;
    for (int i = 0; i < size; i++) {
      int fd = _conns[i].conn;
      if (FD_ISSET(fd, &r_set)){
        _handle(fd, all_set);
      }
    }
  }
}


int Server::_accept(int fd, fd_set& eSet, int& maxFd) {
  if (_connCnt == max_conns) {
    return -1;
  }
  struct sockaddr cli;
  socklen_t len = sizeof(struct sockaddr);
  int cfd = accept(fd, &cli, &len);
  if (cfd > 0) {
    maxFd = (maxFd > cfd ? maxFd : cfd);
    _connOpt(add_conn, cfd);
    FD_SET(cfd, &eSet);
  }
  return 0;
}


int Server::_getPeerSock(int fd, int& pub_ip, int& pub_port) {
  struct sockaddr_in cli;
  socklen_t len = sizeof(struct sockaddr);

  int res = ::getpeername(fd, (struct sockaddr*)&cli, &len);
  if ( res >= 0 ){
    pub_ip = cli.sin_addr.s_addr;
    pub_port = cli.sin_port;
    return 0;
  }
  return -1;
}


int Server::_handle(int fd, fd_set& all_set) {
  Tool t;
  int res = t.Recv(fd);
  if ( res < 0 ) {
    close(fd);
    _connOpt(del_conn, fd);
    FD_CLR(fd, &all_set);

    vector<AcsItem>::iterator it = find_if(_acsLst.begin(), _acsLst.end(), AcsItem_finder(fd, 0));
    if (it != _acsLst.end()) {
      _acsLst.erase(it);
    }
    return 0;
  }

  Message* m = t.GetMessage();
  MsgHeader* header = m->GetMsgHeader();
  switch(header->cmd) {
    case access_cmd:
    {
      AcsItem it;
      it.conn = fd;
      it.pri_ip = header->id.host;
      _acsLst.push_back(it);
      break;
    }
    case hole_syn_cmd:
    {
      HoleKey key;
      key.pri_ip = header->id.host;
      key.pri_port = header->id.port;

      int pub_ip = 0, pub_port = 0;
      map<HoleKey, HoleInfo>::iterator it = _holeTbl.find(key);
      if (it == _holeTbl.end()){
        _getPeerSock(fd, pub_ip, pub_port);
        HoleInfo hin;
        memset(&hin, 0, sizeof(HoleInfo));
        hin.source_fd = fd;
        hin.dest_pri_ip = ((HoleSynMsg*)m)->Target();
        hin.source.ip = pub_ip;
        hin.source.port = pub_port;
        _holeTbl.insert(make_pair(key, hin));

        vector<AcsItem>::iterator aIt = find_if(_acsLst.begin(), _acsLst.end(), AcsItem_finder(0, hin.dest_pri_ip));
        if (aIt != _acsLst.end()){

          HoleAckMsg ack;
          ack.SetMsgId(key.pri_ip, key.pri_port);
          ack.SetMacInfo(&(hin.source));
          t.Send((*aIt).conn, &ack);
        }
      }
      break;
    }
    case hole_ack_cmd:
    {
      HoleKey key;
      key.pri_ip = header->id.host;
      key.pri_port = header->id.port;

      int pub_ip = 0, pub_port = 0;
      map<HoleKey, HoleInfo>::iterator it = _holeTbl.find(key);
      if (it != _holeTbl.end()){
        _getPeerSock(fd, pub_ip, pub_port);
        it->second.dest.ip = pub_ip;
        it->second.dest.port = pub_port;
      }
      break;
    }
    case peer_meet_cmd:
    {
      HoleKey key;
      key.pri_ip = header->id.host;
      key.pri_port = header->id.port;

      map<HoleKey, HoleInfo>::iterator it = _holeTbl.find(key);
      if (it != _holeTbl.end()){
        PeerMeetMsg met;
        met.SetMsgId(key.pri_ip, key.pri_port);
        met.SetMacInfo(&(it->second.dest));
        t.Send(it->second.source_fd, &met);
      }
      break;
    }
  }
  return 0;
}

void Server::_connOpt(cAction a, int fd) {
  switch (a) {
    case add_conn:
    {
      int i = 0;
      for (;i < max_conns; i++){
        if ( _conns[i].used == false ){
          break;
        }
      }

      _conns[i].conn = fd;
      _conns[i].used = true;
      _connCnt++;
      break;
    }
    case del_conn:
    {
      for (int i = 0; i < max_conns; i++){
        if ( _conns[i].conn == fd ){
          _conns[i].conn = 0;
          _conns[i].used = false;
          _connCnt--;
          break;
        }
      }
    }
  }
}

int main() {
  Server cs;
  cs.EventLoop(8877, 8888);
}
