#include <unistd.h>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>

#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <iostream>
using namespace std;
typedef struct Param {
  int fd;
  int port;
}Pram;

int _socket(int port) {
  int lfd = socket(AF_INET, SOCK_STREAM, 0);
  if (lfd < 0) {
    cout << "create socket error: " << strerror(errno) << endl;
    return -1;
  }

  int on = 1;
  if ( setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(int)) == -1) {
    cout << "setsockopt error: " << strerror(errno) << endl;
    return -2;
  }

  struct sockaddr_in svr_addr;
  svr_addr.sin_family = AF_INET;
  svr_addr.sin_port = htons(port);
  svr_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  if ( bind(lfd, (struct sockaddr*)&svr_addr, sizeof(sockaddr_in)) == -1 ){
    cout << "bind error: " << strerror(errno) << endl;
    return  -3;
  }
  return lfd;
}

int _listen(int fd) {
  return listen(fd, 5);
}

void _accept(void* l){
  int fd = *((int*)l);
  cout << "prepare ok..." << endl;
  cout << "begin to accpet ..." << endl;
  struct sockaddr cli_addr;
  socklen_t len = sizeof(sockaddr);
  int f = accept(fd, &cli_addr, &len);
  cout << "accept error: " << strerror(errno) << endl;
  char* hello = "hello, yeji" ;
  int ll = strlen(hello);
  send(f, hello, ll, 0);
  char msg[32] = {0};
  recv(f, msg, 32, 0);
  cout << msg << endl;
  sleep(1000);
     
  return ;
}


void _connect(void* l){
  sleep(5);
  Param * p = (Param*)l;
  int fd = p->fd;
  int port = p->port;

  struct sockaddr_in svr_addr;
  svr_addr.sin_family = AF_INET;
  svr_addr.sin_port = htons(port);
  svr_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
  socklen_t len = sizeof(struct sockaddr);

  int f =  connect(fd, (struct sockaddr*)&svr_addr, len) ;
  if (f == 0) {
     cout << " connect : " << fd << endl; 
     char* hello = "hello, hzyeji" ;
     int ll = strlen(hello);
     send(fd, hello, ll, 0);
     char msg[32] = {0};
     recv(fd, msg, 32, 0);
     cout << msg << endl;
  } else {
     cout << "connect: " << strerror(errno) << endl;
  }
  sleep(3000);
  return ;
}

typedef enum Role {
  client = 0,
  server = 1,
}Role;



int main(){
  map<int, Role> rs;
  int sfd = 0, cfd = 0;
  int result = 0;
  {
    sfd = _socket(2000);
    result = _listen(sfd);
    if ( resut != 0 ) {
       cout << "_listen error" << endl;
       return;
    } else {
       rs.insert(make_pair<sfd, server>);
    }
  }  
  
  {
    cfd = _socket(2000);
    rs.insert(make_pair<cfd, client>);
  }


  fd_set all_set, r_set;
  FD_ZERO(&all_set);
  FD_SET(sfd, &all_set);
  FD_SET(cfd, &all_set);
  int maxfd = (sfd > cfd ? sfd : cfd);
  while(1){
    FD_ZERO(&r_set);
    r_set = all_set;
    result = select(maxfd+1, &r_set, NULL, NULL, NULL);
    if (result < 0) {
      cout << "select event error" << endl;
      continue;
    }
    map<int, Role>::iterator it = rs.begin();
    for (; it != rs.end(); it++){//不考虑删除
      Role r = it->second;
      int conn = it->first;
      FD_ISSET(conn, &r_set);
    }
  }
}
