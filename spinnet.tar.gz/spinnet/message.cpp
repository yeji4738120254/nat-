#include "message.h"
#include <string.h>


Message::Message(Cmd c, int bytes) {
  int size = sizeof(MsgHeader) + bytes;
  m_buff = new char[size];
  memset(m_buff, 0, size);
  MsgHeader *h = (MsgHeader*)m_buff;
  h->cmd = c;
  h->bytes = bytes;
}

Message::~Message(){
  delete [] m_buff;
  m_buff = NULL;
}

void Message::SetMsgId(int host, int port) {
  MsgHeader *h = (MsgHeader*)m_buff;
  h->id.host = host;

  h->id.port = port;
}

MsgHeader* Message::GetMsgHeader() const {
  return (MsgHeader*)m_buff;
}


char* Message::GetMsg(int& len) const {
  MsgHeader *h = (MsgHeader*)m_buff;
  len = sizeof(MsgHeader) + h->bytes;
  return m_buff;
}

AccessMsg::AccessMsg(): Message(access_cmd){
}

AccessMsg::~AccessMsg(){
}

HoleSynMsg::HoleSynMsg() : Message(hole_syn_cmd, sizeof(int)){
}

HoleSynMsg::~HoleSynMsg(){
}


void HoleSynMsg::SetTarget(int target) {
  memcpy(m_buff + sizeof(MsgHeader), (char*)&target, sizeof(int));
}

int HoleSynMsg::Target() const {
  int target = 0;
  memcpy(&target, m_buff + sizeof(MsgHeader), ((MsgHeader*)m_buff)->bytes);
  return target;
}

HoleAckMsg::HoleAckMsg() : Message(hole_ack_cmd, sizeof(MacInfo)){
}

int HoleAckMsg::SetMacInfo(const MacInfo* m) {
  MsgHeader* header = (MsgHeader*)m_buff;
  if (!header || header->bytes != sizeof(MacInfo)){
    return -1;
  }
  memcpy(m_buff + sizeof(MsgHeader), m, sizeof(MacInfo));
  return 0;
}

int HoleAckMsg::GetMacInfo(MacInfo* m) {
  MsgHeader* header = (MsgHeader*)m_buff;
  if (!header || header->bytes != sizeof(MacInfo)){
    return -1;
  }
  memcpy(m, m_buff + sizeof(MsgHeader), sizeof(MacInfo));
  return 0;
}

HoleAckMsg::~HoleAckMsg() {
}


PeerMeetMsg::PeerMeetMsg() : Message(peer_meet_cmd, sizeof(MacInfo)) {
}

PeerMeetMsg::~PeerMeetMsg() {
}


int PeerMeetMsg::SetMacInfo(const MacInfo* m) {
  MsgHeader* header = (MsgHeader*)m_buff;
  if (!header || header->bytes != sizeof(MacInfo)){
    return -1;
  }
  memcpy(m_buff + sizeof(MsgHeader), m, sizeof(MacInfo));
  return 0;
}

int PeerMeetMsg::GetMacInfo(MacInfo* m) {
  MsgHeader* header = (MsgHeader*)m_buff;
  if (!header || header->bytes != sizeof(MacInfo)){
    return -1;
  }
  memcpy(m, m_buff + sizeof(MsgHeader), sizeof(MacInfo));
  return 0;
}
