#pragma once 
#include "message.h"

class Tool {
  public:
    Tool(){};
    ~Tool();

    int Recv(int fd);
    int Send(int fd, const Message* m);
    Message* GetMessage() const { return _m; }
  private:
    Message* _m;
};

void printf_mac(int ip, int port); 
