#include "tool.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <unistd.h>
#include <string.h>
#include <iostream>
#include <arpa/inet.h>

using namespace std;

Tool::~Tool(){
  if (_m != NULL) {
    delete _m;
    _m = NULL;
  }
}

int Tool::Recv(int fd){
  MsgHeader header;
  memset(&header, 0, sizeof(MsgHeader));

  char* pBegin = (char*)&header;
  int pos = 0;
  int left = sizeof(MsgHeader);
  while( left > 0 ) {
    int cnt = recv(fd, pBegin + pos, left, 0);
    if ( cnt == -1) {
      return -1;
    } else if ( cnt == 0 ) {
      return -2;
    } else {
      pos += cnt;
      left -= cnt;
    }
  }

  pos = 0;
  int sz = 0;
  _m = new Message(header.cmd, header.bytes);
  _m->SetMsgId(header.id.host, header.id.port);
  left = header.bytes;
  pBegin = _m->GetMsg(sz) + sizeof(MsgHeader);
  while (left > 0) {
    int cnt = recv(fd, pBegin + pos, left, 0);
    if ( cnt == -1) {
      return -1;
    } else if ( cnt == 0 ) {
      return -2;
    } else {
      pos += cnt;
      left -= cnt;
    }
  }
  return 0;
}

int Tool::Send(int fd, const Message* m) {
  int left = 0;
  int pos = 0;
  char* pBegin = const_cast<char*>(m->GetMsg(left));

  while (left > 0) {
    int cnt = send(fd, pBegin + pos, left, 0);
    if ( cnt == -1) {
      return -1;
    } else {
      pos += cnt;
      left -= cnt;
    }
  }
  return 0;
}


void printf_mac(int ip, int port) {
  struct in_addr in;
  in.s_addr = ip;
  char *hip = inet_ntoa(in);
  int  hp = ntohs(port);

  cout << "network seq ip : " << ip << " port: " << port << endl;
  cout << "host : " << hip << " port: " << hp << endl;
}
