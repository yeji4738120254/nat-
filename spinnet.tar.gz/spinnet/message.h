#pragma once

typedef struct HoleKey {
  int pri_ip;
  int pri_port;

  bool operator <(const HoleKey &other) const {
    if ( pri_ip < other.pri_ip ) {
      return true;
    } else if ( pri_ip == other.pri_ip ){
      return pri_port < other.pri_port;
    } else {
      return false;
    }
  }
}HoleKey;

typedef enum Cmd {
  invail_cmd = 0, //非法命令，不处理
  access_cmd, //上报接入消息，主动端口
  hole_syn_cmd,//申请打洞，请求方协调端口发送打洞申请;外网机通过主连接发送源的转换后的ip:port发送给目的方
  hole_ack_cmd,//打洞目的端主动端口读取源端信息;协调端口回复外网机
  peer_meet_cmd,//准备就绪
}Cmd;

//format 
//header + message

typedef struct MsgId {
  int host;
  int port;
}MsgId;

typedef struct MsgHeader {
  Cmd cmd;
  int bytes;
  MsgId id;
}MsgHeader;

class Message {
  protected:
    char* m_buff;

  public:
    Message(Cmd c, int bytes = 0);
    virtual ~Message();


  public:
    void SetMsgId(int host, int port = 0);
    MsgHeader* GetMsgHeader() const;
    char*      GetMsg(int &len) const;
};
//只需要ip，不需要port
class AccessMsg : public Message {
  public:
    AccessMsg();
    ~AccessMsg();

};


class HoleSynMsg : public Message {
  public:
    HoleSynMsg();
    ~HoleSynMsg();
    void SetTarget(int target);
    int  Target() const;

};

typedef struct MacInfo {
  int ip;
  int port;
}MacInfo;


class HoleAckMsg : public Message {
  public:
    HoleAckMsg();
    ~HoleAckMsg();
    int  SetMacInfo(const MacInfo* m);
    int  GetMacInfo(MacInfo* m);
};

class PeerMeetMsg : public Message {
  public:
    PeerMeetMsg();
    ~PeerMeetMsg();

    int  SetMacInfo(const MacInfo* m);
    int  GetMacInfo(MacInfo* m);
}; 
