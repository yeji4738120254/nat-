#!/bin/sh
g++ -o hole_client ../message.h ../message.cpp ../tool.h ../tool.cpp hole_client.h hole_client.cpp -g -lpthread
