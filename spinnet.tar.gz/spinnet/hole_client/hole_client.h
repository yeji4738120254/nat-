#pragma once

#include <string>
#include <vector>
#include <algorithm>
#include "../message.h"
typedef struct HoleInfo {
  MacInfo pub_local;
  MacInfo pri_remote;
  MacInfo pub_remote;
}HoleInfo;

class HoleInfo_finder {
  private:
    MacInfo _pri_remote;
  public:
    HoleInfo_finder(MacInfo& pri_remote);
    ~HoleInfo_finder();

    bool operator ()(std::vector<HoleInfo>::value_type &value) {
      if (_pri_remote.ip == value.pri_remote.ip 
          && _pri_remote.port == value.pri_remote.port){
        return true;
      }
      return false;
    }
};


class HoleCustomer {
  public:
    HoleCustomer(std::string localIp);
    ~HoleCustomer();

    int HoleAsServer(std::string outIp, int lPort, int cPort);
    int HoleAsClient(std::string outIp, int lPort, int cPort, int target);


  private:
    int _connectTo(std::string ip, int port, int& fd);
    int _connectTo(int ip, int port, int& fd);
    int _connectTo(int localPort, int ip, int port, int& fd);
    int _listenTo(int port);
    int _getLocalname(int conn, MacInfo& mInfo);

    int _holeForServer(std::string ip, int port);
    int _holeForClient(std::string ip, int port);

    int _getLocalName(int fd, MacInfo& mLocal);
  private:
    static void* _connTask(void* ptr);

  private:
    int _monSocket;
    int _localIp;//主机序
};
