#include <unistd.h>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>

#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <iostream>
#include <pthread.h>
#include "hole_client.h"
#include "../tool.h"
#include "../message.h"
using namespace std;

typedef struct tInfo {
  HoleCustomer* obj;
  int     lPort;
  MacInfo m;
}tInfo;

HoleCustomer::HoleCustomer(string localIp):_monSocket(0){
  in_addr_t local = inet_addr(localIp.c_str());
  _localIp = local;
}

HoleCustomer::~HoleCustomer(){
  if (_monSocket != 0) {
    close(_monSocket);
  }
}

int HoleCustomer::HoleAsServer(string outIp, int lPort, int cPort){
  int rs = _connectTo(outIp, lPort, _monSocket);
  if ( rs < 0 ){
    if ( _monSocket > 0 )
      cout << "pub connect error" << endl;
      close(_monSocket);
    return -1;
  }

  return _holeForServer(outIp,  cPort);
}

int HoleCustomer::HoleAsClient(string outIp, int lPort, int cPort, int target){
  int rs = _connectTo(outIp, lPort, _monSocket);
  if (rs < 0) {
    if (_monSocket > 0)
      close(_monSocket);
    return -1;
  }

  AccessMsg acs;
  acs.SetMsgId(_localIp, 0);
  Tool t;
  rs = t.Send(_monSocket, &acs);
  if (rs != 0) {
    return -1;
  }

  int conn = 0;
  rs = _connectTo(outIp, cPort, conn);
  if (rs < 0) {
    if (conn > 0)
      close(conn);
    return -1;
  }

  HoleSynMsg sync;
  sync.SetMsgId(_localIp, 2000);
  sync.SetTarget(target);
  t.Send(conn, &sync);



  t.Recv(conn);
  PeerMeetMsg* met = (PeerMeetMsg*)(t.GetMessage());
  MacInfo m;
  met->GetMacInfo(&m);
  MacInfo local;
  _getLocalName(conn, local);
  cout << "conn fd is : " << conn << endl;
  close(conn);

  pthread_t pid;
  tInfo ti;
  ti.obj = this;
  ti.lPort = local.port;
  memcpy(&(ti.m), &m, sizeof(MacInfo));
  pthread_create(&pid, NULL, (void* (*)(void*))_connTask, &ti);
  sleep(5);
  int fd = _listenTo(local.port);
  struct sockaddr cli;
  socklen_t lt = sizeof(struct sockaddr);
  cout << accept(fd, &cli, &lt) << endl;
  cout << strerror(errno) << endl;
  return 0;
}

int HoleCustomer::_connectTo(string ip, int port, int& fd){
  in_addr_t in = inet_addr(ip.c_str());
  int lip = in;
  return _connectTo(lip, htons(port), fd);
}


int HoleCustomer::_connectTo(int ip, int port, int& fd) {
  fd = socket(AF_INET, SOCK_STREAM, 0);
  if (fd < 0) {
    cout << "create socket error" << endl;
    return -1;
  }


  int on = 1;
  if ( setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(int)) == -1) {
    cout << "set socket option error" << endl;
    return -2;
  }

  struct sockaddr_in remote;
  memset(&remote, 0, sizeof(struct sockaddr));
  remote.sin_family = AF_INET;
  remote.sin_addr.s_addr = ip;
  remote.sin_port = port;
  cout << "public server info: " << endl;
  printf_mac(ip, port);
  if ( 0 != connect(fd, (struct sockaddr*)&remote, sizeof(struct sockaddr))){
     cout << strerror(errno) << endl;;
     return -4;
  }
  return 0;
}

int HoleCustomer::_connectTo(int localPort, int ip, int port, int&fd){
  fd = socket(AF_INET, SOCK_STREAM, 0);
  if (fd < 0) {
    cout << "create socket error" << endl;
    return -1;
  }

  int on = 1;
  if ( setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(int)) == -1) {
    cout << "set socket option error" << endl;
    return -2;
  }
  struct sockaddr_in self_addr;
  memset(&self_addr, 0, sizeof(struct sockaddr_in));
  self_addr.sin_family = AF_INET;
  self_addr.sin_port = localPort;
  self_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  if ( bind(fd, (struct sockaddr*)&self_addr, sizeof(sockaddr_in)) == -1 ){
    cout << "connect bind error: " << strerror(errno) << endl;
    return -3;
  }

  struct sockaddr_in remote;
  memset(&remote, 0, sizeof(struct sockaddr));
  remote.sin_family = AF_INET;
  remote.sin_addr.s_addr = ip;
  remote.sin_port = port;
  cout << "public server info: " << endl;
  printf_mac(ip, port);
  while(1){
    int res =  connect(fd, (struct sockaddr*)&remote, sizeof(struct sockaddr));
    if (res != 0) {
      cout << strerror(errno) << endl;
      sleep(2);
      continue;
    } else {
      cout << "connect ok ..." << res << endl;

      char hello[64];;
      while(1){
        int cnt = recv(fd, hello, 64, 0);
        cout << "recv bytes" << cnt << ", " << hello << endl;
      }
      return fd;
    }
   }
   return -4;
}


int HoleCustomer::_listenTo(int port) {
  int lfd = socket(AF_INET, SOCK_STREAM, 0);
  if (lfd < 0) {
    cout << "create socket error: " << strerror(errno) << endl;
    return -1;
  }

  int on = 1;
  if ( setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(int)) == -1) {
    cout << "setsockopt error: " << strerror(errno) << endl;
    return -2;
  }

  struct sockaddr_in svr_addr;
  memset(&svr_addr, 0, sizeof(struct sockaddr_in));
  svr_addr.sin_family = AF_INET;
  svr_addr.sin_port = port;
  svr_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  if ( bind(lfd, (struct sockaddr*)&svr_addr, sizeof(sockaddr_in)) == -1 ){
    cout << "bind error: " << strerror(errno) << endl;
    return -3;
  }

  if ( listen(lfd, 5) == -1) {
    cout << "listen error: " << strerror(errno) << endl;
    return -4;
  }
  return lfd;
}

int HoleCustomer::_holeForServer(string outIp, int cPort){
  AccessMsg acs;
  acs.SetMsgId(_localIp, 0);
  cout << "active port(8877) send access_cmd " << endl;
  printf_mac(_localIp, 0);
  Tool t;
  int res = t.Send(_monSocket, &acs);
  if (res != 0) {
    return -1;
  }
  res = t.Recv(_monSocket);
  if (res != 0) {
    return -1;
  }

  HoleAckMsg* m = (HoleAckMsg*)(t.GetMessage());
  if (!m || m->GetMsgHeader()->cmd != hole_ack_cmd) {
    cout << "recv hole ack error" << endl;
    return -3;
  }

  int conn = 0;
  res = _connectTo(outIp, cPort, conn);
  if (res != 0) {
    cout << "connect cport  error" << endl;
    return -4;
  }
  MacInfo local;
  _getLocalName(conn, local);
  cout << "get coordinate port(8888) local info " << endl;
  printf_mac(local.ip, local.port);

  MacInfo peer;
  m->GetMacInfo(&peer);
  cout << "hole_ack_cmd get coordinate port(8888) remote info " << endl;
  printf_mac(peer.ip, peer.port);

  HoleInfo hIn;
  memcpy(&(hIn.pri_remote), &(m->GetMsgHeader()->id), sizeof(MacInfo));
  cout << "remote pri (request): " << endl;
  printf_mac(hIn.pri_remote.ip, hIn.pri_remote.port);
  memcpy(&(hIn.pub_remote), &peer, sizeof(MacInfo));
  cout << "remote pub: " << endl;
  printf_mac(hIn.pub_remote.ip, hIn.pub_remote.port);

  HoleAckMsg ack;
  ack.SetMsgId(m->GetMsgHeader()->id.host, m->GetMsgHeader()->id.port);
  ack.SetMacInfo(&peer);
  cout << "send hole_ack_cmd over..." << endl;
  t.Send(conn, &ack);
  close(conn);

  pthread_t pid;
  tInfo ti;
  ti.obj = this;
  ti.lPort = local.port;
  memcpy(&(ti.m), &(hIn.pub_remote), sizeof(MacInfo));
  pthread_create(&pid, NULL, (void* (*)(void*))_connTask, &ti);
  memcpy(&(hIn.pub_local), &local, sizeof(MacInfo));
  sleep(3);
  int fd = _listenTo(local.port);
  struct sockaddr_in svr_addr;

  PeerMeetMsg met;
  met.SetMsgId(m->GetMsgHeader()->id.host, m->GetMsgHeader()->id.port);
  met.SetMacInfo(&local);
  t.Send(_monSocket, &met);

  struct sockaddr cli;
  socklen_t lt = sizeof(struct sockaddr);
  cout << accept(fd, &cli, &lt) << endl;
  cout << strerror(errno) << endl;

  return 0;

}

void* HoleCustomer::_connTask(void* prt){
  tInfo* t = (tInfo*)prt;
  int conn = 0;
  t->obj->_connectTo(t->lPort, t->m.ip, t->m.port, conn);
}

int HoleCustomer::_getLocalName(int fd, MacInfo& mLocal) {
  struct sockaddr_in local;
  socklen_t len = sizeof(struct sockaddr_in);
  if (::getsockname(fd, (struct sockaddr*)&local, &len) == -1 ){
    return -1;
  }
  mLocal.ip = local.sin_addr.s_addr;
  mLocal.port = local.sin_port;
  return 0;
}


string outIp = "192.168.8.140";
int    outlPort = 8877;
int    outcPort = 8888;

string holeSvrIp = "192.168.15.130";
string holeCliIp = "192.168.114.113";
//string holeCliIp = "192.168.36.141";

int main(int argc, char* argv[]) {
  if (argc != 2) {
    return -1;
  }

  if (strcmp(argv[1], "s") == 0) {
    HoleCustomer h(holeSvrIp);
    h.HoleAsServer(outIp, outlPort, outcPort);
  } else {
    HoleCustomer h(holeCliIp);
    in_addr_t tar = inet_addr(holeSvrIp.c_str());
    int target = tar;
    h.HoleAsClient(outIp, outlPort, outcPort, tar);
  }
}
